// Logger Module for Fingerprintify
// Controls console output based on debug level

window.FingerprintifyModules = window.FingerprintifyModules || {};

window.FingerprintifyModules.logger = {
  name: 'Logger',
  description: 'Manages console output for production and development',
  
  // Log levels: 0=NONE, 1=ERROR, 2=WARN, 3=INFO, 4=DEBUG
  currentLevel: 0, // PRODUCTION: Set to 0, DEVELOPMENT: Set to 4
  
  levels: {
    NONE: 0,
    ERROR: 1,
    WARN: 2, 
    INFO: 3,
    DEBUG: 4
  },
  
  init: function() {
    // Auto-detect if development mode
    // You can manually set this to 0 for production builds
    const isDevelopment = false; // SET TO FALSE FOR PRODUCTION!
    this.currentLevel = isDevelopment ? this.levels.DEBUG : this.levels.NONE;
    
    if (this.currentLevel > 0) {
      console.log('🛡️ Fingerprintify Logger: Level', this.currentLevel);
    }
  },
  
  error: function(module, message, ...args) {
    if (this.currentLevel >= this.levels.ERROR) {
      console.error(`❌ ${module}: ${message}`, ...args);
    }
  },
  
  warn: function(module, message, ...args) {
    if (this.currentLevel >= this.levels.WARN) {
      console.warn(`⚠️ ${module}: ${message}`, ...args);
    }
  },
  
  info: function(module, message, ...args) {
    if (this.currentLevel >= this.levels.INFO) {
      console.log(`🛡️ ${module}: ${message}`, ...args);
    }
  },
  
  debug: function(module, message, ...args) {
    if (this.currentLevel >= this.levels.DEBUG) {
      console.log(`🔧 ${module}: ${message}`, ...args);
    }
  },
  
  success: function(module, message, ...args) {
    if (this.currentLevel >= this.levels.INFO) {
      console.log(`✅ ${module}: ${message}`, ...args);
    }
  }
};


// Utility Functions Module
// Provides common functions for all modules

window.FingerprintifyModules = window.FingerprintifyModules || {};

window.FingerprintifyModules.utils = {
  name: 'Utility Functions',
  description: 'Common helper functions for all modules',
  
  // Session-consistent random values
  sessionSeed: Date.now() + Math.random(),
  seedCounter: 0,
  
  deterministicRandom: function() {
    this.seedCounter++;
    const x = Math.sin(this.sessionSeed + this.seedCounter) * 10000;
    return x - Math.floor(x);
  },
  
  randomInt: function(min, max) {
    return Math.floor(this.deterministicRandom() * (max - min + 1)) + min;
  },
  
  randomChoice: function(array) {
    return array[Math.floor(this.deterministicRandom() * array.length)];
  },
  
  // Initialize session-specific values
  init: function() {
    this.sessionSeed = Date.now() + Math.random();
    this.seedCounter = 0;
    if (window.FingerprintifyModules && window.FingerprintifyModules.logger) {
      window.FingerprintifyModules.logger.debug('Utils', 'Initialized with session seed: ' + this.sessionSeed);
    }
  }
};


// Settings Manager Module
// Handles loading and managing protection settings

window.FingerprintifyModules = window.FingerprintifyModules || {};

window.FingerprintifyModules.settings = {
  name: 'Settings Manager',
  description: 'Handles loading and managing protection settings',
  
  defaultSettings: {
    navigator: true,   // Default ON for testing
    screen: true,      // Default ON for testing
    webgl: true,       // Default ON for testing
    canvas: true,      // Default ON for testing
    audio: true,       // Default ON for testing
    fonts: false,      // Not implemented yet
    webrtc: true,      // Default ON for testing
    tracking: false    // Not implemented yet
  },
  
  currentSettings: null,
  
  loadSettings: function() {
    return new Promise((resolve) => {
      if (window.FingerprintifyModules && window.FingerprintifyModules.logger) {
        window.FingerprintifyModules.logger.debug('Settings', 'Loading protection settings...');
      }
      
      let settingsLoaded = false;
      let protectionSettings = { ...this.defaultSettings };
      
      // Try to load from window variable first
      if (window._fingerprintifyPreloadedSettings) {
        protectionSettings = { ...protectionSettings, ...window._fingerprintifyPreloadedSettings };
        settingsLoaded = true;
        if (window.FingerprintifyModules && window.FingerprintifyModules.logger) {
          window.FingerprintifyModules.logger.debug('Settings', 'Using preloaded settings: ' + JSON.stringify(protectionSettings));
        }
        this.currentSettings = protectionSettings;
        resolve(protectionSettings);
        return;
      }
      
      // Try to load from DOM attribute (CSP safe)
      const checkForSettings = () => {
        const settingsAttr = document.documentElement.getAttribute('data-fingerprintify-settings');
        if (settingsAttr) {
          try {
            const parsedSettings = JSON.parse(settingsAttr);
            // Only use if settings are not all false (real settings vs defaults)
            const hasRealSettings = Object.values(parsedSettings).some(value => value === true);
            if (hasRealSettings || !settingsLoaded) {
              protectionSettings = { ...protectionSettings, ...parsedSettings };
              settingsLoaded = true;
              if (window.FingerprintifyModules && window.FingerprintifyModules.logger) {
                window.FingerprintifyModules.logger.debug('Settings', 'Loaded from DOM: ' + JSON.stringify(protectionSettings));
              }
              this.currentSettings = protectionSettings;
              resolve(protectionSettings);
              return true;
            }
          } catch (e) {
            if (window.FingerprintifyModules && window.FingerprintifyModules.logger) {
              window.FingerprintifyModules.logger.warn('Settings', 'Failed to parse DOM settings, using defaults');
            }
          }
        }
        return false;
      };
      
      // Try immediately
      if (!checkForSettings()) {
        // If not found, observe for changes with timeout
        const observer = new MutationObserver(() => {
          if (checkForSettings()) {
            observer.disconnect();
            if (window.FingerprintifyModules && window.FingerprintifyModules.logger) {
              window.FingerprintifyModules.logger.debug('Settings', 'Loaded via observer');
            }
          }
        });
        
        observer.observe(document.documentElement, {
          attributes: true,
          attributeFilter: ['data-fingerprintify-settings']
        });
        
        // Timeout for settings loading
        setTimeout(() => {
          observer.disconnect();
          if (!settingsLoaded) {
            if (window.FingerprintifyModules && window.FingerprintifyModules.logger) {
              window.FingerprintifyModules.logger.info('Settings', 'No real settings found after timeout, using defaults (all OFF)');
            }
            this.currentSettings = protectionSettings;
            resolve(protectionSettings);
          }
        }, 2000);
      }
    });
  },
  
  updateSettings: function(newSettings) {
    this.currentSettings = { ...this.currentSettings, ...newSettings };
    window._fingerprintifySettings = this.currentSettings;
    if (window.FingerprintifyModules && window.FingerprintifyModules.logger) {
      window.FingerprintifyModules.logger.debug('Settings', 'Updated to: ' + JSON.stringify(this.currentSettings));
    }
    return this.currentSettings;
  },
  
  getSettings: function() {
    return this.currentSettings || this.defaultSettings;
  }
};


// Navigator Spoofing Module
// Spoofs browser and hardware information

window.FingerprintifyModules = window.FingerprintifyModules || {};

window.FingerprintifyModules.navigator = {
  name: 'Navigator Spoofing',
  description: 'Spoofs browser and hardware information',
  
  apply: function(protectionSettings, utils) {
    if (!protectionSettings.navigator) {
      if (window.FingerprintifyModules && window.FingerprintifyModules.logger) {
        window.FingerprintifyModules.logger.info('Navigator', 'Protection disabled');
      }
      return;
    }
    
    if (window.FingerprintifyModules && window.FingerprintifyModules.logger) {
      window.FingerprintifyModules.logger.info('Navigator', 'Applying spoofing...');
    }
    
    // VÖLLIG UNREALISTISCHE UserAgents - Existieren nicht!
    const spoofedUserAgents = [
      'Mozilla/5.0 (Windows NT 15.0; Win128; x128) AppleWebKit/999.99 (KHTML, like Gecko) Chrome/250.0.0.0 Safari/999.99',
      'Mozilla/5.0 (Macintosh; Intel Mac OS X 20_50_99) AppleWebKit/777.77 (KHTML, like Gecko) Chrome/300.0.0.0 Safari/777.77',
      'Mozilla/5.0 (QuantumOS 12.5; Quantum64; x64) AppleWebKit/888.88 (KHTML, like Gecko) HyperBrowser/500.0.0.0',
      'Mozilla/5.0 (Windows NT 12.0; ARM128; aarch128) WebKit/666.66 (KHTML, like Gecko) FutureFox/999.0',
      'Mozilla/5.0 (UltraLinux 99.9; x256) AppleWebKit/1111.11 (KHTML, like Gecko) QuantumChrome/777.0.0.0',
      'Mozilla/5.0 (HoloWindows 25.0; Win256; x256) HyperWebKit/2000.0 (KHTML, like Gecko) MetaBrowser/1000.0.0.0',
      'Mozilla/5.0 (CyberMac; Intel Quantum X 50_0_0) AppleWebKit/3000.0 (KHTML, like Gecko) NeuralSafari/888.0.0.0',
      'Mozilla/5.0 (NeoAndroid 25.0; ARM256; aarch256) AppleWebKit/4444.44 (KHTML, like Gecko) CyberChrome/1500.0.0.0',
      'Mozilla/5.0 (HyperOS 99.0; Quantum128; x128) AppleWebKit/5555.55 (KHTML, like Gecko) UltraBrowser/2000.0.0.0',
      'Mozilla/5.0 (MetaWindows 50.0; Win512; x512) NeuralWebKit/9999.99 (KHTML, like Gecko) QuantumFox/5000.0'
    ];
    
    // UNMÖGLICHE Platforms - Existieren nicht!
    const spoofedPlatforms = [
      'Win128', 'Win256', 'Win512', 'Win1024',
      'MacQuantum', 'MacNeural', 'MacHolo', 'MacCyber',
      'Linux x256', 'Linux x512', 'Linux quantum64', 'Linux neural128',
      'UltraLinux', 'HyperLinux', 'QuantumLinux', 'NeuralLinux',
      'QuantumOS', 'HoloWindows', 'CyberMac', 'NeoAndroid',
      'ARM256', 'ARM512', 'ARM1024', 'QuantumARM',
      'HyperX86', 'UltraX64', 'QuantumX128', 'NeuralX256',
      'MetaOS', 'HyperOS', 'FutureOS', 'NeuroOS'
    ];
    
    // UNREALISTISCHE CPU-Kerne
    const spoofedCores = [
      3, 5, 7, 9, 11, 13, 15, 17, 20, 24, 28, 32, 
      48, 64, 96, 128, 256, 512, 1024, 2048, 4096,
      33, 37, 41, 47, 53, 67, 73, 97, 129, 257
    ];
    
    // Create fake navigator object
    const fakeNav = {
      userAgent: utils.randomChoice(spoofedUserAgents),
      platform: utils.randomChoice(spoofedPlatforms), 
      language: 'quantum-QU',
      languages: ['quantum-QU', 'neural-NE', 'en-US'],
      hardwareConcurrency: utils.randomChoice(spoofedCores),
      deviceMemory: [3, 6, 12, 24, 48, 96, 128, 256, 512, 1024][utils.randomInt(0, 9)],
      maxTouchPoints: [0, 1, 2, 5, 10, 16, 32, 64, 128, 256][utils.randomInt(0, 9)],
      cookieEnabled: [true, false][utils.randomInt(0, 1)],
      doNotTrack: ['1', '0', null, 'unspecified', 'quantum', 'neural'][utils.randomInt(0, 5)],
      vendor: utils.randomChoice(['Quantum Corp', 'HoloTech Inc', 'CyberSoft Ltd', 'QuantumTech Inc.', 'NeuralProcessing Ltd.']),
      vendorSub: '',
      product: 'Gecko',
      productSub: '20030107',
      appName: 'Netscape',
      appVersion: utils.randomChoice(['5.0 (QuantumOS)', '5.0 (HoloWindows)', '5.0 (CyberMac)']),
      onLine: true,
      plugins: [],
      mimeTypes: [],
      userAgentData: {
        brands: [
          { brand: 'QuantumBrowser', version: '500' },
          { brand: 'Not)A;Brand', version: '99' },
          { brand: 'HyperChrome', version: '888' }
        ],
        mobile: false,
        platform: utils.randomChoice(spoofedPlatforms)
      }
    };
    
    // Apply navigator spoofing
    try {
      Object.defineProperty(window, 'navigator', {
        get: () => fakeNav,
        configurable: false
      });
      if (window.FingerprintifyModules && window.FingerprintifyModules.logger) {
        window.FingerprintifyModules.logger.success('Navigator', 'Complete window.navigator override applied');
      }
    } catch(e) {
      // Fallback: Override individual properties
      try {
        Object.defineProperty(navigator, 'userAgent', {
          value: fakeNav.userAgent,
          writable: false,
          configurable: false
        });
        Object.defineProperty(navigator, 'platform', {
          value: fakeNav.platform,
          writable: false,
          configurable: false
        });
        Object.defineProperty(navigator, 'hardwareConcurrency', {
          value: fakeNav.hardwareConcurrency,
          writable: false,
          configurable: false
        });
        Object.defineProperty(navigator, 'deviceMemory', {
          value: fakeNav.deviceMemory,
          writable: false,
          configurable: false
        });
        Object.defineProperty(navigator, 'maxTouchPoints', {
          value: fakeNav.maxTouchPoints,
          writable: false,
          configurable: false
        });
        Object.defineProperty(navigator, 'userAgentData', {
          value: fakeNav.userAgentData,
          writable: false,
          configurable: false
        });
        if (window.FingerprintifyModules && window.FingerprintifyModules.logger) {
          window.FingerprintifyModules.logger.success('Navigator', 'Individual property overrides applied');
        }
      } catch(e2) {
        if (window.FingerprintifyModules && window.FingerprintifyModules.logger) {
          window.FingerprintifyModules.logger.warn('Navigator', 'Partial override failed: ' + e2.message);
        }
      }
    }
    
    if (window.FingerprintifyModules && window.FingerprintifyModules.logger) {
      window.FingerprintifyModules.logger.debug('Navigator', 'UserAgent: ' + fakeNav.userAgent);
      window.FingerprintifyModules.logger.debug('Navigator', 'Platform: ' + fakeNav.platform);
      window.FingerprintifyModules.logger.debug('Navigator', 'Hardware Cores: ' + fakeNav.hardwareConcurrency);
      window.FingerprintifyModules.logger.debug('Navigator', 'Device Memory: ' + fakeNav.deviceMemory + 'GB');
    }
    
    return fakeNav;
  }
};


// Screen Spoofing Module
// Spoofs screen resolution and color depth

window.FingerprintifyModules = window.FingerprintifyModules || {};

window.FingerprintifyModules.screen = {
  name: 'Screen Spoofing',
  description: 'Spoofs screen resolution and color depth',
  
  apply: function(protectionSettings, utils) {
    if (!protectionSettings.screen) {
      if (window.FingerprintifyModules && window.FingerprintifyModules.logger) {
        window.FingerprintifyModules.logger.info('Screen', 'Protection disabled');
      }
      return;
    }
    
    if (window.FingerprintifyModules && window.FingerprintifyModules.logger) {
      window.FingerprintifyModules.logger.info('Screen', 'Applying spoofing...');
    }
    
    // SEMI-REALISTISCHE Auflösungen - Ungewöhnlich aber nicht unmöglich
    const spoofedResolutions = [
      { width: 1920, height: 1080 },    // Standard aber häufig
      { width: 2560, height: 1440 },    // Standard QHD
      { width: 3440, height: 1440 },    // Ultrawide
      { width: 2560, height: 1600 },    // 16:10 Format
      { width: 1366, height: 768 },     // Alte Laptops
      { width: 1440, height: 900 },     // Ungewöhnlich aber real
      { width: 2048, height: 1152 },    // Seltene Auflösung
      { width: 2304, height: 1440 },    // MacBook Pro Retina
      { width: 1680, height: 1050 },    // Alte Monitore
      { width: 1600, height: 900 },     // 16:9 aber ungewöhnlich
      { width: 1536, height: 864 }      // 125% Skalierung
    ];
    
    const chosenRes = utils.randomChoice(spoofedResolutions);
    const fakeColorDepth = [24, 32][utils.randomInt(0, 1)]; // Nur realistische Werte
    
    try {
      Object.defineProperties(window.screen, {
        width: { get: () => chosenRes.width, configurable: false },
        height: { get: () => chosenRes.height, configurable: false },
        availWidth: { get: () => chosenRes.width - utils.randomInt(0, 100), configurable: false },
        availHeight: { get: () => chosenRes.height - utils.randomInt(0, 100), configurable: false },
        colorDepth: { get: () => fakeColorDepth, configurable: false },
        pixelDepth: { get: () => fakeColorDepth, configurable: false }
      });
      
      if (window.FingerprintifyModules && window.FingerprintifyModules.logger) {
        window.FingerprintifyModules.logger.success('Screen', 'Spoofing applied');
        window.FingerprintifyModules.logger.debug('Screen', 'Resolution: ' + chosenRes.width + 'x' + chosenRes.height);
        window.FingerprintifyModules.logger.debug('Screen', 'Color Depth: ' + fakeColorDepth + ' bits');
      }
      
    } catch(e) {
      if (window.FingerprintifyModules && window.FingerprintifyModules.logger) {
        window.FingerprintifyModules.logger.warn('Screen', 'Override failed: ' + e.message);
      }
    }
    
    return { resolution: chosenRes, colorDepth: fakeColorDepth };
  }
};


// WebGL Spoofing Module
// Spoofs WebGL renderer and vendor information

window.FingerprintifyModules = window.FingerprintifyModules || {};

window.FingerprintifyModules.webgl = {
  name: 'WebGL Spoofing',
  description: 'Spoofs WebGL renderer and vendor information',
  
  apply: function(protectionSettings, utils) {
    if (!protectionSettings.webgl) {
      if (window.FingerprintifyModules && window.FingerprintifyModules.logger) {
        window.FingerprintifyModules.logger.info('WebGL', 'Protection disabled');
      }
      return;
    }
    
    if (window.FingerprintifyModules && window.FingerprintifyModules.logger) {
      window.FingerprintifyModules.logger.info('WebGL', 'Applying spoofing...');
    }
    
    const vendors = [
      'QuantumTech Inc.', 'HyperGraphics Corp.', 'NeuralProcessing Ltd.',
      'CyberVision Systems', 'MetaGraphics Inc.', 'UltraRendering Co.',
      'FutureGPU Corp.', 'HolographicTech', 'QuantumGraphics LLC'
    ];
    
    const renderers = [
      'QuantumTech UltraGPU 9000X',
      'HyperGraphics Neural RTX 50000',
      'CyberVision HoloCard 8K Pro',
      'MetaGraphics Quantum RTX 99999',
      'Intel(R) Neural Graphics 2050',
      'AMD Radeon Quantum RX 50000X',
      'NVIDIA HyperForce RTX 90000 Ti',
      'Apple M25 Ultra Neural Pro',
      'FutureGPU QuantumCore 128GB'
    ];
    
    const fakeWebGLInfo = {
      vendor: utils.randomChoice(vendors),
      renderer: utils.randomChoice(renderers),
      version: utils.randomChoice(['WebGL 5.0', 'WebGL 9.9', 'QuantumGL 10.0', 'HyperWebGL 25.0']),
      shadingLanguageVersion: utils.randomChoice(['WebGL GLSL ES 5.00', 'QuantumGLSL ES 10.0', 'NeuralGLSL ES 99.0'])
    };
    
    // Override WebGL1 getParameter
    if (window.WebGLRenderingContext) {
      const originalWebGLGetParameter = WebGLRenderingContext.prototype.getParameter;
      WebGLRenderingContext.prototype.getParameter = function(parameter) {
        switch(parameter) {
          case this.VENDOR: return fakeWebGLInfo.vendor;
          case this.RENDERER: return fakeWebGLInfo.renderer;
          case this.VERSION: return fakeWebGLInfo.version;
          case this.SHADING_LANGUAGE_VERSION: return fakeWebGLInfo.shadingLanguageVersion;
          case this.UNMASKED_VENDOR_WEBGL: return fakeWebGLInfo.vendor;
          case this.UNMASKED_RENDERER_WEBGL: return fakeWebGLInfo.renderer;
          case this.MAX_TEXTURE_SIZE: return 32768;
          case this.MAX_RENDERBUFFER_SIZE: return 32768;
          case this.MAX_VIEWPORT_DIMS: return new Int32Array([32768, 32768]);
          default: return originalWebGLGetParameter.call(this, parameter);
        }
      };
      if (window.FingerprintifyModules && window.FingerprintifyModules.logger) {
        window.FingerprintifyModules.logger.success('WebGL', 'WebGL1 getParameter overridden');
      }
    }
    
    // Override WebGL2 getParameter
    if (window.WebGL2RenderingContext) {
      const originalWebGL2GetParameter = WebGL2RenderingContext.prototype.getParameter;
      WebGL2RenderingContext.prototype.getParameter = function(parameter) {
        switch(parameter) {
          case this.VENDOR: return fakeWebGLInfo.vendor;
          case this.RENDERER: return fakeWebGLInfo.renderer;
          case this.VERSION: return fakeWebGLInfo.version;
          case this.SHADING_LANGUAGE_VERSION: return fakeWebGLInfo.shadingLanguageVersion;
          case this.UNMASKED_VENDOR_WEBGL: return fakeWebGLInfo.vendor;
          case this.UNMASKED_RENDERER_WEBGL: return fakeWebGLInfo.renderer;
          default: return originalWebGL2GetParameter.call(this, parameter);
        }
      };
      if (window.FingerprintifyModules && window.FingerprintifyModules.logger) {
        window.FingerprintifyModules.logger.success('WebGL', 'WebGL2 getParameter overridden');
      }
    }
    
    if (window.FingerprintifyModules && window.FingerprintifyModules.logger) {
      window.FingerprintifyModules.logger.debug('WebGL', 'Vendor: ' + fakeWebGLInfo.vendor);
      window.FingerprintifyModules.logger.debug('WebGL', 'Renderer: ' + fakeWebGLInfo.renderer);
      window.FingerprintifyModules.logger.debug('WebGL', 'Version: ' + fakeWebGLInfo.version);
    }
    
    return fakeWebGLInfo;
  }
};


// Canvas Protection Module
// Adds noise to canvas fingerprints

window.FingerprintifyModules = window.FingerprintifyModules || {};

window.FingerprintifyModules.canvas = {
  name: 'Canvas Protection',
  description: 'Adds noise to canvas fingerprints',
  
  apply: function(protectionSettings, utils) {
    if (!protectionSettings.canvas) {
      if (window.FingerprintifyModules.logger) {
        window.FingerprintifyModules.logger.info('Canvas', 'Protection disabled');
      }
      return;
    }
    
    if (window.FingerprintifyModules.logger) {
      window.FingerprintifyModules.logger.info('Canvas', 'Applying protection...');
    }
    
    const originalGetContext = HTMLCanvasElement.prototype.getContext;
    HTMLCanvasElement.prototype.getContext = function(contextType, contextAttributes) {
      const context = originalGetContext.call(this, contextType, contextAttributes);
      
      if (contextType === '2d' && context) {
        // Override getImageData with massive noise injection
        const originalGetImageData = context.getImageData;
        context.getImageData = function(sx, sy, sw, sh) {
          const imageData = originalGetImageData.call(this, sx, sy, sw, sh);
          // Add subtle but effective noise (reduced from 50% to 10%)
          for (let i = 0; i < imageData.data.length; i += 4) {
            if (utils.deterministicRandom() < 0.1) {
              // Subtle changes instead of completely random pixels
              imageData.data[i] = Math.min(255, Math.max(0, imageData.data[i] + utils.randomInt(-20, 20)));     // R
              imageData.data[i + 1] = Math.min(255, Math.max(0, imageData.data[i + 1] + utils.randomInt(-20, 20))); // G
              imageData.data[i + 2] = Math.min(255, Math.max(0, imageData.data[i + 2] + utils.randomInt(-20, 20))); // B
            }
          }
          return imageData;
        };
        
        // Override fillText to add subtle variations (reduced offset)
        const originalFillText = context.fillText;
        context.fillText = function(text, x, y, maxWidth) {
          const offsetX = (utils.deterministicRandom() - 0.5) * 0.5; // Reduced from 2 to 0.5
          const offsetY = (utils.deterministicRandom() - 0.5) * 0.5; // Reduced from 2 to 0.5
          return originalFillText.call(this, text, x + offsetX, y + offsetY, maxWidth);
        };
        
        // Override strokeText similarly (reduced offset)
        const originalStrokeText = context.strokeText;
        context.strokeText = function(text, x, y, maxWidth) {
          const offsetX = (utils.deterministicRandom() - 0.5) * 0.5; // Reduced from 2 to 0.5
          const offsetY = (utils.deterministicRandom() - 0.5) * 0.5; // Reduced from 2 to 0.5
          return originalStrokeText.call(this, text, x + offsetX, y + offsetY, maxWidth);
        };
        
        if (window.FingerprintifyModules.logger) {
          window.FingerprintifyModules.logger.success('Canvas', '2D context protection applied');
        }
      }
      
      // WebGL context spoofing
      if ((contextType === 'webgl' || contextType === 'experimental-webgl' || contextType === 'webgl2') && context) {
        const originalReadPixels = context.readPixels;
        context.readPixels = function(x, y, width, height, format, type, pixels) {
          originalReadPixels.call(this, x, y, width, height, format, type, pixels);
          // Add noise to WebGL fingerprint
          if (pixels && pixels.length) {
            for (let i = 0; i < pixels.length; i++) {
              if (utils.deterministicRandom() > 0.7) {
                pixels[i] = Math.floor(utils.deterministicRandom() * 256);
              }
            }
          }
        };
        if (window.FingerprintifyModules.logger) {
          window.FingerprintifyModules.logger.success('Canvas', 'WebGL context protection applied');
        }
      }
      
      return context;
    };
    
    // Override toDataURL with subtle noise
    const originalToDataURL = HTMLCanvasElement.prototype.toDataURL;
    HTMLCanvasElement.prototype.toDataURL = function(type, encoderOptions) {
      const ctx = this.getContext('2d');
      if (ctx && this.width > 0 && this.height > 0) {
        try {
          // Add subtle random pixels before conversion (reduced intensity)
          const imageData = ctx.getImageData(0, 0, this.width, this.height);
          for (let i = 0; i < imageData.data.length; i += 4) {
            if (utils.deterministicRandom() < 0.05) { // Reduced from 0.3 to 0.05
              imageData.data[i] = Math.min(255, Math.max(0, imageData.data[i] + utils.randomInt(-5, 5)));
              imageData.data[i + 1] = Math.min(255, Math.max(0, imageData.data[i + 1] + utils.randomInt(-5, 5)));
              imageData.data[i + 2] = Math.min(255, Math.max(0, imageData.data[i + 2] + utils.randomInt(-5, 5)));
            }
          }
          ctx.putImageData(imageData, 0, 0);
        } catch (e) {
          // If getImageData fails, just continue without noise
          if (window.FingerprintifyModules.logger) {
            window.FingerprintifyModules.logger.warn('Canvas', 'Could not add noise to toDataURL');
          }
        }
      }
      return originalToDataURL.call(this, type, encoderOptions);
    };
    
    if (window.FingerprintifyModules.logger) {
      window.FingerprintifyModules.logger.success('Canvas', 'Complete protection applied');
    }
  }
};


// Audio Spoofing Module
// Randomizes audio context fingerprints

window.FingerprintifyModules = window.FingerprintifyModules || {};

window.FingerprintifyModules.audio = {
  name: 'Audio Spoofing',
  description: 'Randomizes audio context fingerprints',
  
  apply: function(protectionSettings, utils) {
    if (!protectionSettings.audio) {
      if (window.FingerprintifyModules && window.FingerprintifyModules.logger) {
        window.FingerprintifyModules.logger.info('Audio', 'Protection disabled');
      }
      return;
    }
    
    if (window.FingerprintifyModules && window.FingerprintifyModules.logger) {
      window.FingerprintifyModules.logger.info('Audio', 'Applying spoofing...');
    }
    
    if (window.AudioContext || window.webkitAudioContext) {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      
      // Override createOscillator
      const originalCreateOscillator = AudioCtx.prototype.createOscillator;
      AudioCtx.prototype.createOscillator = function() {
        const oscillator = originalCreateOscillator.call(this);
        const originalConnect = oscillator.connect;
        oscillator.connect = function(destination) {
          // Add slight frequency variation to scramble audio fingerprint
          if (this.frequency) {
            this.frequency.value = this.frequency.value + (utils.deterministicRandom() - 0.5) * 0.001;
          }
          return originalConnect.call(this, destination);
        };
        return oscillator;
      };
      if (window.FingerprintifyModules && window.FingerprintifyModules.logger) {
        window.FingerprintifyModules.logger.success('Audio', 'createOscillator overridden');
      }
      
      // Override createAnalyser
      const originalCreateAnalyser = AudioCtx.prototype.createAnalyser;
      AudioCtx.prototype.createAnalyser = function() {
        const analyser = originalCreateAnalyser.call(this);
        const originalGetFloatFrequencyData = analyser.getFloatFrequencyData;
        
        analyser.getFloatFrequencyData = function(array) {
          originalGetFloatFrequencyData.call(this, array);
          // Add noise to audio fingerprinting
          for (let i = 0; i < array.length; i++) {
            array[i] += (utils.deterministicRandom() - 0.5) * 0.1;
          }
        };
        
        return analyser;
      };
      if (window.FingerprintifyModules && window.FingerprintifyModules.logger) {
        window.FingerprintifyModules.logger.success('Audio', 'createAnalyser overridden');
      }
      
      if (window.FingerprintifyModules && window.FingerprintifyModules.logger) {
        window.FingerprintifyModules.logger.success('Audio', 'Complete spoofing applied');
      }
    } else {
      if (window.FingerprintifyModules && window.FingerprintifyModules.logger) {
        window.FingerprintifyModules.logger.warn('Audio', 'AudioContext not available');
      }
    }
  }
};


// WebRTC Blocking Module
// Prevents IP leaks through WebRTC connections

window.FingerprintifyModules = window.FingerprintifyModules || {};

window.FingerprintifyModules.webrtc = {
  name: 'WebRTC Blocking',
  description: 'Blocks WebRTC to prevent IP leaks',
  
  apply: function(protectionSettings) {
    if (!protectionSettings.webrtc) {
      if (window.FingerprintifyModules && window.FingerprintifyModules.logger) {
        window.FingerprintifyModules.logger.info('WebRTC', 'Protection disabled');
      }
      return;
    }
    
    if (window.FingerprintifyModules && window.FingerprintifyModules.logger) {
      window.FingerprintifyModules.logger.info('WebRTC', 'Applying complete blocking...');
    }
    
    // Block RTCPeerConnection constructors
    if (window.RTCPeerConnection) {
      window.RTCPeerConnection = function() {
        throw new Error('WebRTC blocked by Fingerprintify');
      };
      if (window.FingerprintifyModules && window.FingerprintifyModules.logger) {
        window.FingerprintifyModules.logger.success('WebRTC', 'RTCPeerConnection blocked');
      }
    }
    
    if (window.webkitRTCPeerConnection) {
      window.webkitRTCPeerConnection = function() {
        throw new Error('WebRTC blocked by Fingerprintify');
      };
      if (window.FingerprintifyModules && window.FingerprintifyModules.logger) {
        window.FingerprintifyModules.logger.success('WebRTC', 'webkitRTCPeerConnection blocked');
      }
    }
    
    if (window.mozRTCPeerConnection) {
      window.mozRTCPeerConnection = function() {
        throw new Error('WebRTC blocked by Fingerprintify');
      };
      console.log('🛡️ WebRTC: mozRTCPeerConnection blocked');
    }
    
    // Block getUserMedia
    if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
      navigator.mediaDevices.getUserMedia = function() {
        return Promise.reject(new Error('Media access blocked by Fingerprintify'));
      };
      if (window.FingerprintifyModules && window.FingerprintifyModules.logger) {
        window.FingerprintifyModules.logger.success('WebRTC', 'getUserMedia blocked');
      }
    }
    
    // Override legacy getUserMedia
    if (navigator.getUserMedia) {
      navigator.getUserMedia = function(constraints, success, error) {
        if (error) error(new Error('Media access blocked by Fingerprintify'));
      };
      if (window.FingerprintifyModules && window.FingerprintifyModules.logger) {
        window.FingerprintifyModules.logger.success('WebRTC', 'Legacy getUserMedia blocked');
      }
    }
    
    if (window.FingerprintifyModules && window.FingerprintifyModules.logger) {
      window.FingerprintifyModules.logger.success('WebRTC', 'Complete blocking applied');
    }
  }
};


// Fingerprintify Main Module
// Loads and coordinates all protection modules

(function() {
  'use strict';
  
  // Initialize logger first
  if (window.FingerprintifyModules && window.FingerprintifyModules.logger) {
    window.FingerprintifyModules.logger.init();
    window.FingerprintifyModules.logger.info('Fingerprintify', 'Modular protection system starting...');
  }
  
  // Set global flags
  window._fingerprintifyActive = true;
  window._fingerprintifySession = 'session_' + Date.now();
  window._fingerprintifyProfile = Math.floor(Math.random() * 10) + 1;
  
  // Initialize protection system
  async function initializeProtection() {
    try {
      // Wait for all modules to be loaded
      if (!window.FingerprintifyModules) {
        console.log('⚠️ Fingerprintify: Modules not loaded yet, retrying...');
        setTimeout(initializeProtection, 100);
        return;
      }
      
      const modules = window.FingerprintifyModules;
      
      // Initialize utilities first
      if (modules.utils) {
        modules.utils.init();
      } else {
        console.error('❌ Fingerprintify: Utils module not found!');
        return;
      }
      
      // Load settings
      let protectionSettings;
      if (modules.settings) {
        protectionSettings = await modules.settings.loadSettings();
      } else {
        if (modules.logger) {
          modules.logger.error('Fingerprintify', 'Settings module not found!');
        }
        return;
      }
      
      window._fingerprintifySettings = protectionSettings;
      
      if (modules.logger) {
        modules.logger.info('Fingerprintify', 'Applying protection modules...');
      }
      
      // Apply protection modules in order
      const results = {};
      
      // 1. Navigator spoofing (affects other modules)
      if (modules.navigator) {
        results.navigator = modules.navigator.apply(protectionSettings, modules.utils);
      }
      
      // 2. Screen spoofing
      if (modules.screen) {
        results.screen = modules.screen.apply(protectionSettings, modules.utils);
      }
      
      // 3. WebGL spoofing
      if (modules.webgl) {
        results.webgl = modules.webgl.apply(protectionSettings, modules.utils);
      }
      
      // 4. Canvas protection
      if (modules.canvas) {
        modules.canvas.apply(protectionSettings, modules.utils);
      }
      
      // 5. Audio spoofing
      if (modules.audio) {
        modules.audio.apply(protectionSettings, modules.utils);
      }
      
      // 6. WebRTC blocking (important for security)
      if (modules.webrtc) {
        modules.webrtc.apply(protectionSettings);
      }
      
      if (modules.logger) {
        modules.logger.success('Fingerprintify', 'All modules applied successfully!');
        modules.logger.debug('Fingerprintify', 'Session: ' + window._fingerprintifySession);
        modules.logger.debug('Fingerprintify', 'Settings: ' + JSON.stringify(protectionSettings));
      }
      
      // Log protection status
      if (results.navigator && modules.logger) {
        modules.logger.debug('Fingerprintify', 'UserAgent: ' + results.navigator.userAgent);
        modules.logger.debug('Fingerprintify', 'Platform: ' + results.navigator.platform);
        modules.logger.debug('Fingerprintify', 'Hardware Cores: ' + results.navigator.hardwareConcurrency);
        modules.logger.debug('Fingerprintify', 'Device Memory: ' + results.navigator.deviceMemory + 'GB');
      }
      
      if (results.screen && modules.logger) {
        modules.logger.debug('Fingerprintify', 'Screen: ' + (protectionSettings.screen ? 
          results.screen.resolution.width + 'x' + results.screen.resolution.height + 'x' + results.screen.colorDepth : 
          'DISABLED - original values'));
      }
      
      if (results.webgl && modules.logger) {
        modules.logger.debug('Fingerprintify', 'WebGL Vendor: ' + (protectionSettings.webgl ? results.webgl.vendor : 'DISABLED - original values'));
        modules.logger.debug('Fingerprintify', 'WebGL Renderer: ' + (protectionSettings.webgl ? results.webgl.renderer : 'DISABLED - original values'));
      }
      
      if (modules.logger) {
        modules.logger.info('Fingerprintify', 'Canvas Protection: ' + (protectionSettings.canvas ? 'ENABLED' : 'DISABLED'));
        modules.logger.info('Fingerprintify', 'Audio Protection: ' + (protectionSettings.audio ? 'ENABLED' : 'DISABLED'));
        modules.logger.info('Fingerprintify', 'WebRTC Blocking: ' + (protectionSettings.webrtc ? 'ENABLED' : 'DISABLED'));
        modules.logger.info('Fingerprintify', 'Navigator Spoofing: ' + (protectionSettings.navigator ? 'ENABLED' : 'DISABLED'));
      }
      
      // Function to update settings dynamically 
      window.updateFingerprintifySettings = function(newSettings) {
        const oldSettings = modules.settings.getSettings();
        const updatedSettings = modules.settings.updateSettings(newSettings);
        
        if (modules.logger) {
          modules.logger.debug('Fingerprintify', 'Settings updated from: ' + JSON.stringify(oldSettings) + ' to: ' + JSON.stringify(updatedSettings));
          modules.logger.info('Fingerprintify', 'Note: Some protections require page reload to take effect');
        }
        
        // Store settings globally for detection
        window._fingerprintifySettingsActive = updatedSettings;
      };
      
      // CSP-safe communication: Listen for status requests from content script
      document.addEventListener('fingerprintify-status-request', function(event) {
        const statusData = {
          active: window._fingerprintifyActive || false,
          session: window._fingerprintifySession || null,
          settings: window._fingerprintifySettings || null,
          navigator: {
            userAgent: navigator.userAgent,
            platform: navigator.platform,
            hardwareConcurrency: navigator.hardwareConcurrency,
            deviceMemory: navigator.deviceMemory,
            maxTouchPoints: navigator.maxTouchPoints,
            language: navigator.language,
            vendor: navigator.vendor
          },
          screen: {
            width: screen.width,
            height: screen.height,
            colorDepth: screen.colorDepth,
            pixelDepth: screen.pixelDepth
          }
        };
        
        // Send response via CustomEvent
        const responseEvent = new CustomEvent('fingerprintify-status-response', {
          detail: {
            type: 'fingerprintify-status',
            data: statusData
          }
        });
        document.dispatchEvent(responseEvent);
        
        if (modules.logger) {
          modules.logger.debug('Fingerprintify', 'Status sent to content script: ' + (statusData.active ? 'ACTIVE' : 'INACTIVE'));
        }
      });
      
      // Listen for settings updates from content script
      document.addEventListener('fingerprintify-settings-update', function(event) {
        if (event.detail && event.detail.type === 'settings-update') {
          const newSettings = event.detail.data;
          if (window.updateFingerprintifySettings) {
            window.updateFingerprintifySettings(newSettings);
            if (modules.logger) {
              modules.logger.debug('Fingerprintify', 'Settings updated in main world via event: ' + JSON.stringify(newSettings));
            }
          }
        }
      });
      
    } catch (error) {
      console.error('❌ Fingerprintify: Initialization failed:', error);
    }
  }
  
  // Start initialization
  initializeProtection();
  
})();


